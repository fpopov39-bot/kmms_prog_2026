@echo off
chcp 1251 > log
del log

set MAIN=main.cpp
set EXE=simple_sort_implementation.exe

:: -fexec-charset=utf-8 в Windows не работает
set CHARSET="-finput-charset=utf-8 -fexec-charset=windows-1251"

if exist %EXE% del %EXE%

g++ "%CHARSET%" %MAIN% -o %EXE%

%EXE%
